import discord
from discord.ext import commands
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import re
import names
import pymssql

print("Setting connection standards...")

conn = pymssql.connect(server='68.0.187.171\HOMEEXPRESS', user='odin', password='odin', database='ODIN', port='49172')  
cursor = conn.cursor()

print("Setting variables")
station = "grimhex"

try:
    print("Initiating connection...")
    cursor.execute("SELECT * FROM Market WHERE station=%s", station)
    printOut = cursor.fetchall()
except TypeError as e:
    print(e)

print("Returning server print-out: ", printOut)

print("Closing connection.")
conn.close()

input()