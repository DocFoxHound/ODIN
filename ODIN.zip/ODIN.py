import gspread
from oauth2client.service_account import ServiceAccountCredentials
import re
from discord.ext import commands
import discord

TOKEN = 'NTMzNTIwNTM3NDE1MTg4NDgw.DxsPQw.WeUfXIFs9Dz_U2Gtpj7pSK2yKoM'

the_prefix = '?'

client = commands.Bot(command_prefix=the_prefix)

scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']

credentials = ServiceAccountCredentials.from_json_keyfile_name('ODIN-bd3fd42186ba.json', scope)

gc = gspread.authorize(credentials)

wks = gc.open('Items').get_worksheet(0)

# !! Cogs go in extensions list !! =====================================================================================

extensions = ['sell_cog', 'buy_cog', 'profit_cog', 'testing', 'buyat_cog']

# !! Cogs go in extensions list !! =====================================================================================

@client.event
async def on_ready():
    await client.change_presence(game=discord.Game(name='?odin'))
    print('O.D.I.N. Online...')



@client.event
async def on_member_join(member):
    role = discord.utils.get(member.server.roles, name='O.D.I.N.')
    await client.add_roles(member, role)

@client.event
async def on_command_error(error, ctx):
    channel = ctx.message.channel
    if isinstance(error, commands.CommandNotFound):
        await client.send_message(channel, 'Command does not exist')

@client.command()
async def load(extension):
    try:
        client.load_extension(extension)
        print('Loaded {}'.format(extension))
    except Exception as error:
        print('{} cannot be loaded. [{}]'.format(extension, error))

@client.command()
async def unload(extension):
    try:
        client.unload_extension(extension)
        print('Unloaded {}'.format(extension))
    except Exception as error:
        print('{} cannot be loaded. [{}]'.format(extension, error))

@client.command()
async def odin():
    embed = discord.Embed(
        title='Help Command',
        description='O.D.I.N. Assistant Module',
        color=discord.Color.dark_red()
    )


    embed.set_footer(text='Orical Dynamic Information Network')
    embed.set_thumbnail(url='https://cdn.discordapp.com/avatars/533520537415188480/c21d351059ea7c841fd634fa5081e4f1.png?size=128')
    embed.add_field(name='?buy', value='Takes in:\n Facility you want to buy at (olisar,grim,arc157)\nItem you want to buy(all, ms, wid)', inline=False)
    embed.add_field(name='?sell', value='Takes in:\n Facility you want to sell at (levski,lorville,rrcru1)\nItem you want to sell(was, chl, dia)', inline=False)

    await client.say(embed=embed)

if __name__ == '__main__':
    for extension in extensions:
        try:
            client.load_extension(extension)
        except Exception as error:
            print('{} cannot be loaded. [{}]'.format(extension, error))
    client.run(TOKEN)

#keep from closing
input()